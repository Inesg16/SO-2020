#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <ctype.h>
#include "fs/operations.h"
#include <pthread.h>
#include <time.h>

#define MAX_COMMANDS 150000
#define MAX_INPUT_SIZE 100


pthread_mutex_t lock1, lock2;
pthread_rwlock_t rwlock1, rwlock2;

int numberThreads = 0;

char inputCommands[MAX_COMMANDS][MAX_INPUT_SIZE];
int numberCommands = 0;
int headQueue = 0;

int insertCommand(char* data) {
    if(numberCommands != MAX_COMMANDS) {
        strcpy(inputCommands[numberCommands++], data);
        return 1;
    }
    return 0;
}

char* removeCommand() {
    if(numberCommands > 0){
        numberCommands--;
        return inputCommands[headQueue++];
    }
    return NULL;
}

void errorParse(){
    fprintf(stderr, "Error: command invalid\n");
    exit(EXIT_FAILURE);
}

void processInput(FILE *file_input){
    char line[MAX_INPUT_SIZE];

    /* break loop with ^Z or ^D */
    while (fgets(line, sizeof(line)/sizeof(char), file_input)) {
        char token, type;
        char name[MAX_INPUT_SIZE];

        int numTokens = sscanf(line, "%c %s %c", &token, name, &type);

        /* perform minimal validation */
        if (numTokens < 1) {
            continue;
        }
        switch (token) {
            case 'c':
                if(numTokens != 3)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case 'l':
                if(numTokens != 2)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case 'd':
                if(numTokens != 2)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case '#':
                break;
            
            default: { /* error */
                errorParse();
            }
        }
    }
}

void wr_lock(m_lock, rw_lock) {
    if (pthread_mutex_lock(&m_lock) != 0){
        fprintf(stderr, "Error locking mutex\n");
        exit(EXIT_FAILURE);
    }
    if (pthread_rwlock_wrlock(&rw_lock) != 0){
        fprintf(stderr, "Error locking rwlock\n");
        exit(EXIT_FAILURE);
    }
}


void rd_lock(m_lock, rw_lock) {
    if (pthread_mutex_lock(&m_lock) != 0){
        fprintf(stderr, "Error locking mutex\n");
        exit(EXIT_FAILURE);
    }
    if (pthread_rwlock_rdlock(&rw_lock) != 0){
        fprintf(stderr, "Error locking rwlock\n");
        exit(EXIT_FAILURE);
    }
}

void unlock(m_lock, rw_lock) {
    if (pthread_mutex_unlock(&m_lock) != 0){
        fprintf(stderr, "Error unlocking mutex\n");
        exit(EXIT_FAILURE);
    }
    if (pthread_rwlock_unlock(&rw_lock) != 0){
        fprintf(stderr, "Error unlocking rwlock\n");
        exit(EXIT_FAILURE);
    }
}


void applyCommands(){

    while (numberCommands > 0){

        
        wr_lock(lock1, rwlock1);

        const char* command = removeCommand();
        if (command == NULL)
            continue;

        unlock(lock1, rwlock1);
        

        char token, type;
        char name[MAX_INPUT_SIZE];
        int numTokens = sscanf(command, "%c %s %c", &token, name, &type);
        if (numTokens < 2) {
            fprintf(stderr, "Error: invalid command in Queue\n");
            exit(EXIT_FAILURE);
        }

        int searchResult;
      
        switch (token) {
            case 'c':
                switch (type) {
                    case 'f':
                        wr_lock(lock2, rwlock2);

                        printf("Create file: %s\n", name);
                        create(name, T_FILE);
                        
                        unlock(lock2, rwlock2);
                                               
                        break;
                    case 'd':
                        wr_lock(lock2, rwlock2);

                        printf("Create directory: %s\n", name);
                        create(name, T_DIRECTORY);

                        unlock(lock2, rwlock2);
                        
                        break;
                    default:
                        fprintf(stderr, "Error: invalid node type\n");
                        exit(EXIT_FAILURE);
                }
                break;
            case 'l':
                rd_lock(lock2, rwlock2);

                searchResult = lookup(name);

                unlock(lock2, rwlock2);
                
                if (searchResult >= 0)
                    printf("Search: %s found\n", name);
                else
                    printf("Search: %s not found\n", name);
                break;
            case 'd':
                wr_lock(lock2, rwlock2);

                printf("Delete: %s\n", name);
                delete(name);
                
                unlock(lock2, rwlock2);    

                break;
            default: { /* error */
                fprintf(stderr, "Error: command to apply\n");
                exit(EXIT_FAILURE);
            }
        }
    }
}


void * call_applyCommands(void* ptr){

    applyCommands();

    return NULL;
}

/* given the number of threads it creates and joins them*/
void threads(FILE *file_output, int numberThreads, void *(*f) (void*)){

    pthread_t tid[numberThreads];

    for (int i = 0; i < numberThreads; i++){
        if (pthread_create(&tid[i], NULL, f, NULL) != 0){
            fprintf(stderr, "Error creating thread.\n");

            exit(EXIT_FAILURE);
        }
    }

    for (int i = 0; i < numberThreads; i++){
        if (pthread_join(tid[i], NULL) != 0){
            fprintf(stderr, "Error joining thread.\n");
            exit(EXIT_FAILURE);
        }
    }
}

/* it chooses and initializes which type of sync we are going to use */
void sync(FILE *file_output, int numberThreads, char* syncstrategy){

    if (strcmp(syncstrategy, "nosync") == 0 && numberThreads == 1){
        applyCommands();
    }
    else if (numberThreads >= 1){
        if (strcmp(syncstrategy, "mutex") == 0){
            
            if (pthread_mutex_init(&lock1, NULL) != 0){
                fprintf(stderr, "Error iniciating mutex.\n");
                exit(EXIT_FAILURE);
            }
            if (pthread_mutex_init(&lock2, NULL) != 0){
                fprintf(stderr, "Error iniciating mutex.\n");
                exit(EXIT_FAILURE);
            }

            threads(file_output, numberThreads, call_applyCommands);

            if (pthread_mutex_destroy(&lock1) != 0){
                fprintf(stderr, "Error destroing mutex.\n");
                exit(EXIT_FAILURE);
            }
            if (pthread_mutex_destroy(&lock2) != 0){
                fprintf(stderr, "Error destroing mutex.\n");
                exit(EXIT_FAILURE);
            }
        }
        else if (strcmp(syncstrategy, "rwlock") == 0){

            if (pthread_rwlock_init(&rwlock1, NULL) != 0){
                fprintf(stderr, "Error iniciating rwlock.\n");
                exit(EXIT_FAILURE);
            }
            if (pthread_rwlock_init(&rwlock2, NULL) != 0){
                fprintf(stderr, "Error iniciating rwlock.\n");
                exit(EXIT_FAILURE);
            }

            threads(file_output, numberThreads, call_applyCommands);
        }
        else
            errorParse();
    }
    else 
        errorParse();
}


int main(int argc, char* argv[]) {

    char syncstrategy[6] ;
    FILE *file_input, *file_output;


    if((file_input = fopen(argv[1], "r")) == NULL){
        fprintf(stderr, "Error opening file.\n");
        exit(EXIT_FAILURE);
    }

    /* init filesystem */
    init_fs();

    /* process input */
    processInput(file_input);

    file_output = fopen(argv[2], "w+");

    numberThreads = atoi(argv[3]);

    strcpy(syncstrategy,argv[4]);

    /* starts to count the running time of the program*/
    clock_t begin = clock();

    sync(file_output, numberThreads, syncstrategy);


    clock_t end = clock();
    double time = (double)(end - begin)/ CLOCKS_PER_SEC;
    
    printf("TecnicoFS completed in %0.4lf seconds.\n", time);

     /* print tree */
    print_tecnicofs_tree(file_output);

    fclose(file_input);
    fclose(file_output);

    /* release allocated memory */
    destroy_fs();

    exit(EXIT_SUCCESS);
}
