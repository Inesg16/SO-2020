#include "operations.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

extern inode_t inode_table[INODE_TABLE_SIZE];


void wr_lock(pthread_rwlock_t lock) {
    if (pthread_rwlock_wrlock(&lock) != 0){
        fprintf(stderr, "Error locking rwlock\n");
        exit(EXIT_FAILURE);
    }
}

void rd_lock(pthread_rwlock_t lock) {
    if (pthread_rwlock_rdlock(&lock) != 0){
        fprintf(stderr, "Error locking rwlock\n");
        exit(EXIT_FAILURE);
    }
}

void unlock(pthread_rwlock_t lock) {
    if (pthread_rwlock_unlock(&lock) != 0){
        fprintf(stderr, "Error unlocking rwlock\n");
        exit(EXIT_FAILURE);
    }
}


/* Given a path, fills pointers with strings for the parent path and child
 * file name
 * Input:
 *  - path: the path to split. ATENTION: the function may alter this parameter
 *  - parent: reference to a char*, to store parent path
 *  - child: reference to a char*, to store child file name
 */
void split_parent_child_from_path(char * path, char ** parent, char ** child) {

	int n_slashes = 0, last_slash_location = 0;
	int len = strlen(path);

	// deal with trailing slash ( a/x vs a/x/ )
	if (path[len-1] == '/') {
		path[len-1] = '\0';
	}

	for (int i=0; i < len; ++i) {
		if (path[i] == '/' && path[i+1] != '\0') {
			last_slash_location = i;
			n_slashes++;
		}
	}

	if (n_slashes == 0) { // root directory
		*parent = "";
		*child = path;
		return;
	}

	path[last_slash_location] = '\0';
	*parent = path;
	*child = path + last_slash_location + 1;

}


/*
 * Initializes tecnicofs and creates root node.
 */
void init_fs() {
	inode_table_init();
	
	/* create root inode */
	int root = inode_create(T_DIRECTORY);
	
	if (root != FS_ROOT) {
		printf("failed to create node for tecnicofs root\n");
		exit(EXIT_FAILURE);
	}
}


/*
 * Destroy tecnicofs and inode table.
 */
void destroy_fs() {
	inode_table_destroy();
}


/*
 * Checks if content of directory is not empty.
 * Input:
 *  - entries: entries of directory
 * Returns: SUCCESS or FAIL
 */

int is_dir_empty(DirEntry *dirEntries) {
	if (dirEntries == NULL) {
		return FAIL;
	}
	for (int i = 0; i < MAX_DIR_ENTRIES; i++) {
		if (dirEntries[i].inumber != FREE_INODE) {
			return FAIL;
		}
	}
	return SUCCESS;
}


/*
 * Looks for node in directory entry from name.
 * Input:
 *  - name: path of node
 *  - entries: entries of directory
 * Returns:
 *  - inumber: found node's inumber
 *  - FAIL: if not found
 */
int lookup_sub_node(char *name, DirEntry *entries) {
	if (entries == NULL) {
		return FAIL;
	}
	for (int i = 0; i < MAX_DIR_ENTRIES; i++) {
        if (entries[i].inumber != FREE_INODE && strcmp(entries[i].name, name) == 0) {
            return entries[i].inumber;
        }
    }
	return FAIL;
}


/*
 * Creates a new node given a path.
 * Input:
 *  - name: path of node
 *  - nodeType: type of node
 * Returns: SUCCESS or FAIL
 */
int create(char *name, type nodeType){

	int parent_inumber, child_inumber;
	char *parent_name, *child_name, name_copy[MAX_FILE_NAME];
	/* use for copy */
	type pType;
	union Data pdata;
	/* array of locked inodes */
	inode_t locks_array_create[MAX_LOCKS_ARRAY];

	strcpy(name_copy, name);
	split_parent_child_from_path(name_copy, &parent_name, &child_name);

	parent_inumber = lookup(parent_name, locks_array_create);

	if (parent_inumber == FAIL) {
		printf("failed to create %s, invalid parent dir %s\n",
		        name, parent_name);
		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_create[j].lock);
    	}
		return FAIL;
	}

	inode_get(parent_inumber, &pType, &pdata);

	if(pType != T_DIRECTORY) {
		printf("failed to create %s, parent %s is not a dir\n",
		        name, parent_name);
		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_create[j].lock);
    	}
		return FAIL;
	}

	if (lookup_sub_node(child_name, pdata.dirEntries) != FAIL) {
		printf("failed to create %s, already exists in dir %s\n",
		       child_name, parent_name);
		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_create[j].lock);
    	}
		return FAIL;
	}

	/* wr lock parent_inumber */
	wr_lock(inode_table[parent_inumber].lock);
	/* create node and add entry to folder that contains new node */
	child_inumber = inode_create(nodeType);
	/* unlock parent_inumber */
    unlock(inode_table[parent_inumber].lock);

	if (child_inumber == FAIL) {
		printf("failed to create %s in  %s, couldn't allocate inode\n",
		        child_name, parent_name);
		/* unlocks all locks in array*/
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_create[j].lock);
    	}
		return FAIL;
	}

	if (dir_add_entry(parent_inumber, child_inumber, child_name) == FAIL) {
		printf("could not add entry %s in dir %s\n",
		       child_name, parent_name);
		/* unlocks all locks in array*/
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_create[j].lock);
    	}
		return FAIL;
	}

	/* unlocks all locks in array*/
	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
		unlock(locks_array_create[j].lock);
	}

	return SUCCESS;
}


/*
 * Deletes a node given a path.
 * Input:
 *  - name: path of node
 * Returns: SUCCESS or FAIL
 */
int delete(char *name){

	int parent_inumber, child_inumber;
	char *parent_name, *child_name, name_copy[MAX_FILE_NAME];
	/* use for copy */
	type pType, cType;
	union Data pdata, cdata;
	/* array of locked inodes */
	inode_t locks_array_delete[MAX_LOCKS_ARRAY];

	strcpy(name_copy, name);
	split_parent_child_from_path(name_copy, &parent_name, &child_name);

	parent_inumber = lookup(parent_name, locks_array_delete);

	if (parent_inumber == FAIL) {
		printf("failed to delete %s, invalid parent dir %s\n",
		        child_name, parent_name);
		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_delete[j].lock);
    	}
		return FAIL;
	}

	inode_get(parent_inumber, &pType, &pdata);

	if(pType != T_DIRECTORY) {
		printf("failed to delete %s, parent %s is not a dir\n",
		        child_name, parent_name);
		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_delete[j].lock);
    	}
		return FAIL;
	}

	child_inumber = lookup_sub_node(child_name, pdata.dirEntries);

	if (child_inumber == FAIL) {
		printf("could not delete %s, does not exist in dir %s\n",
		       name, parent_name);
		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_delete[j].lock);
    	}
		return FAIL;
	}

	inode_get(child_inumber, &cType, &cdata);

	if (cType == T_DIRECTORY && is_dir_empty(cdata.dirEntries) == FAIL) {
		printf("could not delete %s: is a directory and not empty\n",
		       name);
		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_delete[j].lock);
    	}
		return FAIL;
	}

	/* remove entry from folder that contained deleted node */
	if (dir_reset_entry(parent_inumber, child_inumber) == FAIL) {
		printf("failed to delete %s from dir %s\n",
		       child_name, parent_name);
		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_delete[j].lock);
    	}
		return FAIL;
	}

	/* wr lock parent_inumber */
	wr_lock(inode_table[parent_inumber].lock);
	if (inode_delete(child_inumber) == FAIL) {
		printf("could not delete inode number %d from dir %s\n",
		       child_inumber, parent_name);
		/* unlock parent_inumber */
    	unlock(inode_table[parent_inumber].lock);
    	/* unlocks all locks in array */
	    for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
	        unlock(locks_array_delete[j].lock);
	    }
		return FAIL;
	}
	/* unlock parent_inumber */
    unlock(inode_table[parent_inumber].lock);

    /* unlocks all locks in array */
    for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        unlock(locks_array_delete[j].lock);
    }

	return SUCCESS;
}


/*
 * Lookup for a given path.
 * Input:
 *  - name: path of node
 * Returns:
 *  inumber: identifier of the i-node, if found
 *     FAIL: otherwise
 */
int lookup(char *name, inode_t *locks_array) {
	char full_path[MAX_FILE_NAME];
	char delim[] = "/";
	char *saveptr;
	int i = 0;

	strcpy(full_path, name);

	/* start at root node */
	int current_inumber = FS_ROOT;
	/* use for copy */
	type nType;
	union Data data;

	/* get root inode data */
	inode_get(current_inumber, &nType, &data);

	char *path = strtok_r(full_path, delim, &saveptr);

	/* search for all sub nodes */
	while (path != NULL && (current_inumber = lookup_sub_node(path, data.dirEntries)) != FAIL) {
		
		rd_lock(inode_table[current_inumber].lock);
		/* add lock to array */
		locks_array[i] = inode_table[current_inumber];
		i++;

		inode_get(current_inumber, &nType, &data);
		path = strtok_r(NULL, delim, &saveptr);
	}

	return current_inumber;
}

/*
 * Moves a file/dir into a new dir.
 * Input:
 *  - name: path of node
 *  - location: new path
 * Returns: SUCCESS or FAIL
 */
int move (char *name, char *location){

	/* array of locked inodes */
	inode_t locks_array_move[MAX_LOCKS_ARRAY*2];

	char *parent_name, *new_parent_name, *child_name, *new_child_name;
	char name_copy[MAX_FILE_NAME], location_copy[MAX_FILE_NAME];
	
	int parent_inumber, new_parent_inumber, child_inumber, new_child_inumber;
	type pType, cType, new_pType;
	union Data pdata, cdata, new_pdata;

	strcpy(name_copy, name);
	strcpy(location_copy, location);
	
	split_parent_child_from_path(name_copy, &parent_name, &child_name);
	split_parent_child_from_path(location_copy, &new_parent_name, &new_child_name);

	/* first argument verifications */
	parent_inumber = lookup(parent_name, locks_array_move);

	if (parent_inumber < 0) {
		printf("failed to move %s, invalid parent dir %s\n",
		        child_name, parent_name);
		/* unlocks all locks in array*/
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		return FAIL;
	}

	inode_get(parent_inumber, &pType, &pdata);

	if(pType != T_DIRECTORY) {
		printf("failed to move %s, parent %s is not a dir\n",
		        child_name, parent_name);
		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		return FAIL;
	}

	child_inumber = lookup_sub_node(child_name, pdata.dirEntries);

	if (child_inumber == FAIL) {
		printf("failed to move %s, does not exist in dir %s\n",
		       name, parent_name);
		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		return FAIL;
	}

	inode_get(child_inumber, &cType, &cdata);

	/* second argument verifications */
	new_parent_inumber = lookup(new_parent_name, locks_array_move);

	if (new_parent_inumber < 0) {
		printf("failed to move %s, dir %s doesn't exists\n",
		        child_name, location_copy);
		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		return FAIL;
	}

	inode_get(new_parent_inumber, &new_pType, &new_pdata);

	if(new_pType != T_DIRECTORY) {
		printf("failed to move %s, new parent %s is not a dir\n",
		        child_name, location_copy);
		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		return FAIL;
	}

	new_child_inumber = lookup_sub_node(new_parent_name, pdata.dirEntries);

	if (new_child_inumber != FAIL) {
		printf("failed to move %s, new child %s already exists\n",
		        child_name, new_child_name);
		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		return FAIL;
	}

	if (strcmp(new_parent_name, name) == 0){
		printf("failed to move %s\n", child_name);
		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		return FAIL;
	}
	/* add entry */
	/* write lock new_parent_inumber */
	wr_lock(inode_table[new_parent_inumber].lock);
	if (dir_add_entry(new_parent_inumber, child_inumber, child_name) == FAIL){
		printf("failed to add entry %s to dir %s\n", child_name, new_parent_name);
		/* unlock (write lock) new_parent_inumber */
		unlock(inode_table[new_parent_inumber].lock);
		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		return FAIL;
	}
	/* unlock (write lock) new_parent_inumber */
	unlock(inode_table[new_parent_inumber].lock);

	/* reset entry */
	/* write lock parent_inumber */
	wr_lock(inode_table[parent_inumber].lock);
	if (dir_reset_entry(parent_inumber, child_inumber) == FAIL){
		printf("failed to reset entry %s in dir %s\n", child_name, parent_name);
		/* unlock (write lock) parent_inumber */
		unlock(inode_table[parent_inumber].lock);
		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		return FAIL;
	}
	/* unlock (write lock) parent_inumber */
	unlock(inode_table[parent_inumber].lock);

	/* unlocks all locks in array */
	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
		unlock(locks_array_move[j].lock);
	}

	return SUCCESS;
}


/*
 * Prints tecnicofs tree.
 * Input:
 *  - fp: pointer to output file
 */
void print_tecnicofs_tree(FILE *fp){
	inode_print_tree(fp, FS_ROOT, "");
}
