#ifndef FS_H
#define FS_H
#include "state.h"

#define MAX_LOCKS_ARRAY 20

void wr_lock(pthread_rwlock_t lock);
void rd_lock(pthread_rwlock_t lock);
void unlock(pthread_rwlock_t lock);

void init_fs();
void destroy_fs();
int is_dir_empty(DirEntry *dirEntries);
int create(char *name, type nodeType);
int delete(char *name);
int lookup(char *name, inode_t *locks_array);
int move (char *name, char *location);
void print_tecnicofs_tree(FILE *fp);

#endif /* FS_H */
