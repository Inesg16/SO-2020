/*********************************
 * Projeto SO - Ano letivo 20/21 *
 * 2o Exercicio                  *
 *********************************
 * Grupo 2:                      *
 * Beatriz Urbano - 96729        *
 * Ines Gomes - 96742            *
 *********************************/


#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <ctype.h>
#include "fs/operations.h"
#include <pthread.h>
#include <sys/time.h>  /*  gettimeofday() */
#include <math.h>

#define MAX_COMMANDS 10
#define MAX_INPUT_SIZE 100

pthread_mutex_t prod_cons_lock;
pthread_cond_t prod;
pthread_cond_t cons;

/* for each thread there will be a "END" command so they can return */
char end_of_file[] = "END";
/* total number of threads (input) */
int numberThreads;
/* table/array with all commands */
char inputCommands[MAX_COMMANDS][MAX_INPUT_SIZE];
/* total number of commands in array */
int numberCommands = 0;
/* consumer index in array */
int headQueue = 0;
/* producer index in array */
int headCommands = 0;


int insertCommand(char* data) {
    /* mutex lock */
    if (pthread_mutex_lock(&prod_cons_lock) != 0){
        fprintf(stderr, "Error locking mutex.\n");
        exit(EXIT_FAILURE);
    }
    while(numberCommands == MAX_COMMANDS){
        if (pthread_cond_wait(&prod, &prod_cons_lock) != 0){
            fprintf(stderr, "Error in cond wait.\n");
            exit(EXIT_FAILURE);
        }
    }

    strcpy(inputCommands[headCommands++], data);

    if (headCommands == MAX_COMMANDS)
        headCommands = 0;

    numberCommands++;

    if (pthread_cond_signal(&cons) != 0){
        fprintf(stderr, "Error in cond signal.\n");
        exit(EXIT_FAILURE);
    }
    /* mutex unlock */
    if (pthread_mutex_unlock(&prod_cons_lock) != 0){
        fprintf(stderr, "Error unlocking mutex.\n");
        exit(EXIT_FAILURE);
    }
    return 1;
}

char* removeCommand() {
    char* res;

    /* mutex lock */
    if (pthread_mutex_lock(&prod_cons_lock) != 0){
        fprintf(stderr, "Error locking mutex.\n");
        exit(EXIT_FAILURE);
    }
    while(numberCommands <= 0){
        if (pthread_cond_wait(&cons, &prod_cons_lock) != 0){
            fprintf(stderr, "Error in cond wait.\n");
            exit(EXIT_FAILURE);
        }
    }

    res = malloc(sizeof(char*) * (strlen(inputCommands[headQueue])+1));
    strcpy(res, inputCommands[headQueue++]);

    if(headQueue == MAX_COMMANDS)
        headQueue = 0;

    numberCommands--;

    if (pthread_cond_signal(&prod) != 0){
        fprintf(stderr, "Error in cond signal.\n");
        exit(EXIT_FAILURE);
    }
    /* mutex unlock */
    if (pthread_mutex_unlock(&prod_cons_lock) != 0){
        fprintf(stderr, "Error unlocking mutex.\n");
        exit(EXIT_FAILURE);
    }
    return res;
}

void errorParse(){
    fprintf(stderr, "Error: command invalid\n");
    exit(EXIT_FAILURE);
}

void processInput(FILE *file_input){
    char line[MAX_INPUT_SIZE];

    /* break loop with ^Z or ^D */
    while (fgets(line, sizeof(line)/sizeof(char), file_input)) {
        char token;
        char name[MAX_INPUT_SIZE], type[MAX_INPUT_SIZE];

        int numTokens = sscanf(line, "%c %s %s", &token, name, type);

        /* perform minimal validation */
        if (numTokens < 1) {
            continue;
        }
        switch (token) {
            case 'c':
                if(numTokens != 3)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case 'l':
                if(numTokens != 2)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case 'd':
                if(numTokens != 2)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;

            case 'm':
                if(numTokens != 3)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case '#':
                break;
            
            default: { /* error */
                errorParse();
            }
        }
    }
    /* add the end of file command for each thread */
    for (int i = 0; i < numberThreads; i++){
        insertCommand(end_of_file);
    }
}

void applyCommands(){

    while (1){

        const char* command = removeCommand();

        /* when the end of file command is reached the current thread will return */
        if (strcmp(end_of_file, command) == 0){
            free((void*)command);
            return;
        }

        char token;
        char name[MAX_INPUT_SIZE], type[MAX_INPUT_SIZE];
        int numTokens = sscanf(command, "%c %s %s", &token, name, type);

        free((void*)command);

        if (numTokens < 2) {
            fprintf(stderr, "Error: invalid command in Queue\n");
            exit(EXIT_FAILURE);
        }

        int searchResult;
        /* array of inodes to be locked by lookup */
        inode_t locks_array[MAX_LOCKS_ARRAY];
      
        switch (token) {
            case 'c':
                if (strcmp(type, "f") == 0){
                    printf("Create file: %s\n", name);
                    create(name, T_FILE);
                    break;
                }
                if (strcmp(type, "d") == 0){
                    printf("Create directory: %s\n", name);
                    create(name, T_DIRECTORY);
                    break;
                }
                else{
                    fprintf(stderr, "Error: invalid node type\n");
                    exit(EXIT_FAILURE);
                }
                break;

            case 'l':
                searchResult = lookup(name, locks_array);

                /* unlocks all locks in array*/
                for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
                    unlock(locks_array[j].lock);
                }

                if (searchResult >= 0)
                    printf("Search: %s found\n", name);
                else
                    printf("Search: %s not found\n", name);
                break;

            case 'd':
                printf("Delete: %s\n", name);
                delete(name);
                break;

            case 'm':
                printf("Move: %s to %s\n", name, type );
                move(name, type);
                break;

            default: { /* error */
                fprintf(stderr, "Error: command to apply\n");
                exit(EXIT_FAILURE);
            }
        }
    }
}

/* given the number of threads it creates and joins them*/
void threads(FILE *file_input, void (*f) , void (*g)) {
    pthread_t prod_thread;
    pthread_t tid[numberThreads];

    /* producer thread */
    if (pthread_create(&prod_thread, NULL, f, file_input) != 0){
        fprintf(stderr, "Error creating thread.\n");
        exit(EXIT_FAILURE);
    }

    /* consumer threads */
    for (int i = 0; i < numberThreads; i++){
        if (pthread_create(&tid[i], NULL, g, NULL) != 0){
            fprintf(stderr, "Error creating thread.\n");
            exit(EXIT_FAILURE);
        }
    }

    if (pthread_join(prod_thread, NULL) != 0){
        fprintf(stderr, "Error joining thread.\n");
        exit(EXIT_FAILURE);
    }

    for (int j = 0; j < numberThreads; j++){
        if (pthread_join(tid[j], NULL) != 0){
            fprintf(stderr, "Error joining thread.\n");
            exit(EXIT_FAILURE);
        }
    }
}


int main(int argc, char* argv[]) {
    FILE *file_input, *file_output;
    struct timeval begin, end;
    
    /* verification: argv has 4 arguments*/
    if (argc != 4){
        errorParse();
    }

    if((file_input = fopen(argv[1], "r")) == NULL){
        fprintf(stderr, "Error opening file.\n");
        exit(EXIT_FAILURE);
    }

    if((file_output = fopen(argv[2], "w+")) == NULL){
        fprintf(stderr, "Error opening file.\n");
        exit(EXIT_FAILURE);
    }

    numberThreads = atoi(argv[3]);
    if (numberThreads <= 0){
        errorParse();
    }

    /* init filesystem */
    init_fs();

    /* inicializing mutexes */
    if (pthread_mutex_init(&prod_cons_lock, NULL) != 0){
        fprintf(stderr, "Error iniciating mutex.\n");
        exit(EXIT_FAILURE);
    }

    /* inicializing cond variables*/
    if (pthread_cond_init(&prod, NULL) != 0){
        fprintf(stderr, "Error iniciating cond.\n");
        exit(EXIT_FAILURE);
    }
    if (pthread_cond_init(&cons, NULL) != 0){
        fprintf(stderr, "Error iniciating cond.\n");
        exit(EXIT_FAILURE);
    }

    /* starts to count the running time of the program */
    gettimeofday(&begin, NULL);
    
    threads(file_input, processInput, applyCommands);

    gettimeofday(&end, NULL);
    float total = (end.tv_sec + end.tv_usec*(pow(10, -6))) - (begin.tv_sec + begin.tv_usec*(pow(10,-6)));
    printf("TecnicoFS completed in %0.4lf seconds.\n", total);

    /* print tree */
    print_tecnicofs_tree(file_output);

    fclose(file_input);
    fclose(file_output);

    mutex_destroy(prod_cons_lock);

    if (pthread_cond_destroy(&prod) != 0){
        fprintf(stderr, "Error destroing cond.\n");
        exit(EXIT_FAILURE);
    }
    if (pthread_cond_destroy(&cons) != 0){
        fprintf(stderr, "Error destroing cond.\n");
        exit(EXIT_FAILURE);
    }

    /* release allocated memory */
    destroy_fs();

    exit(EXIT_SUCCESS);
}
