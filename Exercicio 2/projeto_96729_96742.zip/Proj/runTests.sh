#!/bin/bash 
#runTest inputdir outputdir numThreads


re='^[0-9]+$'
if ! [[ $3 =~ $re ]]; then
	echo "Error invalid argument"
	exit 1
fi

#checks if the input directory exists
if [ ! -d "$1" ]; then
	echo "Error finding Input directory"
	exit 1
fi

#checks if the output directory exits
if [ ! -d "$2" ]; then
	echo "Error finding Output directory"
	exit 1
fi

for input in $1/*.txt
do
	for maxthreads in $(seq $3)
	do
		echo InputFile=$(basename $input) Numthreads=$maxthreads
 	./tecnicofs $input $2/$(basename $input .txt)-$maxthreads.txt $maxthreads | grep 'TecnicoFS completed in'
	done
done
