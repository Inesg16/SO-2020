/**************************
 * Grupo 2: 96729 e 96742 *
 **************************/

#include "tecnicofs-client-api.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdio.h>
#include <sys/types.h>
#include <strings.h>
#include <sys/uio.h>
#include <sys/stat.h>


#define NAME "/tmp/96729_96742"

extern char * serverName;
int sockfd;

int setSockAddrUn(char *path, struct sockaddr_un *addr) {

	if (addr == NULL)
		return 0;

	bzero((char *)addr, sizeof(struct sockaddr_un));
	addr->sun_family = AF_UNIX;
	strcpy(addr->sun_path, path);

	return SUN_LEN(addr);
}

void tfs_send(char * buff){
	socklen_t servlen;
	struct sockaddr_un serv_addr;

	servlen = setSockAddrUn(serverName, &serv_addr);

	if (sendto(sockfd, buff, strlen(buff)+1, 0, (struct sockaddr *) &serv_addr, servlen) < 0) {
	    perror("client: sendto error");
	    exit(EXIT_FAILURE);
	}
}

int tfs_receive(){
	char buffer[1024];
	socklen_t servlen;
	struct sockaddr_un serv_addr;
	int res;

	servlen = setSockAddrUn(serverName, &serv_addr);

	if (recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr *) &serv_addr, &servlen) < 0) {
		perror("client: recvfrom error");
		exit(EXIT_FAILURE);
	}

	printf("Answer from the server: %s", buffer);
	res = strcmp(buffer, "SUCCESS\n");
	return res;
}


int tfsCreate(char *filename, char nodeType) {
	char message[1024];
	int res;

	if (sprintf(message, "c %s %c", filename, nodeType) > 1024){
		fprintf(stderr, "Error: message buffer overflow\n");
    	exit(EXIT_FAILURE);
	}

	tfs_send(message);
	res = tfs_receive();

	return res;
}

int tfsDelete(char *path) {
	char message[1024];
	int res;

	if (sprintf(message, "d %s", path) > 1024){
		fprintf(stderr, "Error: message buffer overflow\n");
    	exit(EXIT_FAILURE);
	}

	tfs_send(message);
	res = tfs_receive();

	return res;
}

int tfsMove(char *from, char *to) {
	char message[1024];
	int res;

	if (sprintf(message, "m %s %s", from, to) > 1024){
		fprintf(stderr, "Error: message buffer overflow\n");
    	exit(EXIT_FAILURE);
	}

	tfs_send(message);
	res = tfs_receive();

	return res;
}

int tfsLookup(char *path) {
	char message[1024];
	int res;

	if (sprintf(message, "l %s",path) > 1024){
		fprintf(stderr, "Error: message buffer overflow\n");
    	exit(EXIT_FAILURE);
	}

	tfs_send(message);
	res = tfs_receive();

	return res;
}

int tfsPrint(char *filename){
	char message[1024];
	int res;

	if (sprintf(message, "p %s", filename) > 1024){
		fprintf(stderr, "Error: message buffer overflow\n");
    	exit(EXIT_FAILURE);
	}

	tfs_send(message);
	res = tfs_receive();

	return res;
}

int tfsMount(char * sockPath) {

	socklen_t clilen;
	struct sockaddr_un client_addr;

	if ((sockfd = socket(AF_UNIX, SOCK_DGRAM, 0)) < 0) {
		perror("client: can't open socket");
		exit(EXIT_FAILURE);
	}

	unlink(NAME);
	clilen = setSockAddrUn (NAME, &client_addr);
	if (bind(sockfd, (struct sockaddr *) &client_addr, clilen) < 0) {
		perror("client: bind error");
		exit(EXIT_FAILURE);
	}
	
	return 0;
}

int tfsUnmount() {
	close(sockfd);
	unlink(NAME);
  return 1;
}
