/**************************
 * Grupo 2: 96729 e 96742 *
 **************************/

#include "operations.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

extern inode_t inode_table[INODE_TABLE_SIZE];
extern int sockfd;

extern pthread_cond_t t; /* stop_threads */
extern pthread_cond_t c; /* working_threads */
extern pthread_mutex_t lock;

int stop_threads = 0;
int working_threads = 0; 


void wr_lock(pthread_rwlock_t lock) {
    if (pthread_rwlock_wrlock(&lock) != 0){
        fprintf(stderr, "Error locking rwlock\n");
        exit(EXIT_FAILURE);
    }
}

void rd_lock(pthread_rwlock_t lock) {
    if (pthread_rwlock_rdlock(&lock) != 0){
        fprintf(stderr, "Error locking rwlock\n");
        exit(EXIT_FAILURE);
    }
}

void unlock(pthread_rwlock_t lock) {
    if (pthread_rwlock_unlock(&lock) != 0){
        fprintf(stderr, "Error unlocking rwlock\n");
        exit(EXIT_FAILURE);
    }
}

/*
 * Send given message to client with the address given.
 */
void send_to_client(char* message, struct sockaddr_un client_addr){
	socklen_t addrlen;
	addrlen = sizeof(struct sockaddr_un);

    sendto(sockfd, message, strlen(message)+1, 0, (struct sockaddr *)&client_addr, addrlen);
}

/*
 * If the flag stop_threads is 1, the current thread waits until the print is done.
 * If the flag stop_threads is 0, add 1 to the number of working_threads.
 */
void print_conditions(){
	/* mutex lock */
	if (pthread_mutex_lock(&lock) != 0){
        fprintf(stderr, "Error locking mutex.\n");
        exit(EXIT_FAILURE);
    }
    while(stop_threads == 1){
        if (pthread_cond_wait(&t, &lock) != 0){
            fprintf(stderr, "Error in cond wait.\n");
            exit(EXIT_FAILURE);
        }
    }
	working_threads++;
    /* mutex unlock */
    if (pthread_mutex_unlock(&lock) != 0){
        fprintf(stderr, "Error unlocking mutex.\n");
        exit(EXIT_FAILURE);
    }
}

/*
 * After executing, the number of working_threads decrements and signals
 * the print function so it can print.
 */
void end_print_conditions(){
	/* mutex lock */
	if (pthread_mutex_lock(&lock) != 0){
        fprintf(stderr, "Error locking mutex.\n");
        exit(EXIT_FAILURE);
    }

	working_threads--;

	if (pthread_cond_signal(&c) != 0){
        fprintf(stderr, "Error in cond signal.\n");
        exit(EXIT_FAILURE);
    }
    /* mutex unlock */
    if (pthread_mutex_unlock(&lock) != 0){
        fprintf(stderr, "Error unlocking mutex.\n");
        exit(EXIT_FAILURE);
    }
}


/* Given a path, fills pointers with strings for the parent path and child
 * file name
 * Input:
 *  - path: the path to split. ATENTION: the function may alter this parameter
 *  - parent: reference to a char*, to store parent path
 *  - child: reference to a char*, to store child file name
 */
void split_parent_child_from_path(char * path, char ** parent, char ** child) {

	int n_slashes = 0, last_slash_location = 0;
	int len = strlen(path);

	// deal with trailing slash ( a/x vs a/x/ )
	if (path[len-1] == '/') {
		path[len-1] = '\0';
	}

	for (int i=0; i < len; ++i) {
		if (path[i] == '/' && path[i+1] != '\0') {
			last_slash_location = i;
			n_slashes++;
		}
	}

	if (n_slashes == 0) { // root directory
		*parent = "";
		*child = path;
		return;
	}

	path[last_slash_location] = '\0';
	*parent = path;
	*child = path + last_slash_location + 1;

}


/*
 * Initializes tecnicofs and creates root node.
 */
void init_fs() {
	inode_table_init();
	
	/* create root inode */
	int root = inode_create(T_DIRECTORY);
	
	if (root != FS_ROOT) {
		printf("failed to create node for tecnicofs root\n");
		exit(EXIT_FAILURE);
	}
}


/*
 * Destroy tecnicofs and inode table.
 */
void destroy_fs() {
	inode_table_destroy();
}


/*
 * Checks if content of directory is not empty.
 * Input:
 *  - entries: entries of directory
 * Returns: SUCCESS or FAIL
 */

int is_dir_empty(DirEntry *dirEntries) {
	if (dirEntries == NULL) {
		return FAIL;
	}
	for (int i = 0; i < MAX_DIR_ENTRIES; i++) {
		if (dirEntries[i].inumber != FREE_INODE) {
			return FAIL;
		}
	}
	return SUCCESS;
}


/*
 * Looks for node in directory entry from name.
 * Input:
 *  - name: path of node
 *  - entries: entries of directory
 * Returns:
 *  - inumber: found node's inumber
 *  - FAIL: if not found
 */
int lookup_sub_node(char *name, DirEntry *entries) {
	if (entries == NULL) {
		return FAIL;
	}
	for (int i = 0; i < MAX_DIR_ENTRIES; i++) {
        if (entries[i].inumber != FREE_INODE && strcmp(entries[i].name, name) == 0) {
            return entries[i].inumber;
        }
    }
	return FAIL;
}


/*
 * Creates a new node given a path.
 * Input:
 *  - name: path of node
 *  - nodeType: type of node
 * Returns: SUCCESS or FAIL
 */
int create(char *name, type nodeType, struct sockaddr_un client_addr){
	int parent_inumber, child_inumber;
	char *parent_name, *child_name, name_copy[MAX_FILE_NAME];
	/* use for copy */
	type pType;
	union Data pdata;
	/* array of locked inodes */
	inode_t locks_array_create[MAX_LOCKS_ARRAY];
	/* sending errors to client */
	char message[OUTDIM];

	print_conditions();

	strcpy(name_copy, name);
	split_parent_child_from_path(name_copy, &parent_name, &child_name);

	parent_inumber = lookup(parent_name, locks_array_create);

	if (parent_inumber == FAIL) {
		sprintf(message, "failed to create %s, invalid parent dir %s\n", name, parent_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_create[j].lock);
    	}
    	end_print_conditions();
		return FAIL;
	}

	inode_get(parent_inumber, &pType, &pdata);

	if(pType != T_DIRECTORY) {
		sprintf(message, "failed to create %s, parent %s is not a dir\n", name, parent_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_create[j].lock);
    	}
    	end_print_conditions();
		return FAIL;
	}

	if (lookup_sub_node(child_name, pdata.dirEntries) != FAIL) {
		sprintf(message, "failed to create %s, already exists in dir %s\n", child_name, parent_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_create[j].lock);
    	}
    	end_print_conditions();
		return FAIL;
	}

	/* wr lock parent_inumber */
	wr_lock(inode_table[parent_inumber].lock);
	/* create node and add entry to folder that contains new node */
	child_inumber = inode_create(nodeType);
	/* unlock parent_inumber */
    unlock(inode_table[parent_inumber].lock);

	if (child_inumber == FAIL) {
		sprintf(message, "failed to create %s in  %s, couldn't allocate inode\n", child_name, parent_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array*/
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_create[j].lock);
    	}
    	end_print_conditions();
		return FAIL;
	}

	if (dir_add_entry(parent_inumber, child_inumber, child_name) == FAIL) {
		sprintf(message, "could not add entry %s in dir %s\n", child_name, parent_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array*/
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_create[j].lock);
    	}
    	end_print_conditions();
		return FAIL;
	}

	/* unlocks all locks in array*/
	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
		unlock(locks_array_create[j].lock);
	}

	end_print_conditions();

	sprintf(message, "SUCCESS\n");
	send_to_client(message, client_addr);
	return SUCCESS;
}


/*
 * Deletes a node given a path.
 * Input:
 *  - name: path of node
 * Returns: SUCCESS or FAIL
 */
int delete(char *name, struct sockaddr_un client_addr){

	int parent_inumber, child_inumber;
	char *parent_name, *child_name, name_copy[MAX_FILE_NAME];
	/* use for copy */
	type pType, cType;
	union Data pdata, cdata;
	/* array of locked inodes */
	inode_t locks_array_delete[MAX_LOCKS_ARRAY];
	/* sending errors to client */
	char message[OUTDIM];

	print_conditions();

	strcpy(name_copy, name);
	split_parent_child_from_path(name_copy, &parent_name, &child_name);

	parent_inumber = lookup(parent_name, locks_array_delete);

	if (parent_inumber == FAIL) {
		sprintf(message, "failed to delete %s, invalid parent dir %s\n", child_name, parent_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_delete[j].lock);
    	}
    	end_print_conditions();
		return FAIL;
	}

	inode_get(parent_inumber, &pType, &pdata);

	if(pType != T_DIRECTORY) {
		sprintf(message, "failed to delete %s, parent %s is not a dir\n", child_name, parent_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_delete[j].lock);
    	}
    	end_print_conditions();
		return FAIL;
	}

	child_inumber = lookup_sub_node(child_name, pdata.dirEntries);

	if (child_inumber == FAIL) {
		sprintf(message, "could not delete %s, does not exist in dir %s\n", name, parent_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_delete[j].lock);
    	}
    	end_print_conditions();
		return FAIL;
	}

	inode_get(child_inumber, &cType, &cdata);

	if (cType == T_DIRECTORY && is_dir_empty(cdata.dirEntries) == FAIL) {
		sprintf(message, "could not delete %s: is a directory and not empty\n", name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_delete[j].lock);
    	}
    	end_print_conditions();
		return FAIL;
	}

	/* remove entry from folder that contained deleted node */
	if (dir_reset_entry(parent_inumber, child_inumber) == FAIL) {
		sprintf(message, "failed to delete %s from dir %s\n", child_name, parent_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array */
    	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        	unlock(locks_array_delete[j].lock);
    	}
    	end_print_conditions();
		return FAIL;
	}

	/* wr lock parent_inumber */
	wr_lock(inode_table[parent_inumber].lock);
	if (inode_delete(child_inumber) == FAIL) {
		sprintf(message, "could not delete inode number %d from dir %s\n", child_inumber, parent_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlock parent_inumber */
    	unlock(inode_table[parent_inumber].lock);
    	/* unlocks all locks in array */
	    for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
	        unlock(locks_array_delete[j].lock);
	    }
	    end_print_conditions();
		return FAIL;
	}
	/* unlock parent_inumber */
    unlock(inode_table[parent_inumber].lock);

    /* unlocks all locks in array */
    for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
        unlock(locks_array_delete[j].lock);
    }

    end_print_conditions();

    sprintf(message, "SUCCESS\n");
	send_to_client(message, client_addr);
	return SUCCESS;
}


/*
 * Lookup for a given path.
 * Input:
 *  - name: path of node
 * Returns:
 *  inumber: identifier of the i-node, if found
 */
int lookup(char *name, inode_t *locks_array) {
	char full_path[MAX_FILE_NAME];
	char delim[] = "/";
	char *saveptr;
	int i = 0;

	strcpy(full_path, name);

	/* start at root node */
	int current_inumber = FS_ROOT;
	/* use for copy */
	type nType;
	union Data data;

	/* get root inode data */
	inode_get(current_inumber, &nType, &data);

	char *path = strtok_r(full_path, delim, &saveptr);

	/* search for all sub nodes */
	while (path != NULL && (current_inumber = lookup_sub_node(path, data.dirEntries)) != FAIL) {
		
		rd_lock(inode_table[current_inumber].lock);
		/* add lock to array */
		locks_array[i] = inode_table[current_inumber];
		i++;

		inode_get(current_inumber, &nType, &data);
		path = strtok_r(NULL, delim, &saveptr);
	}
	return current_inumber;
}

/*
 * Moves a file/dir into a new dir.
 * Input:
 *  - name: path of node
 *  - location: new path
 * Returns: SUCCESS or FAIL
 */
int move (char *name, char *location, struct sockaddr_un client_addr){

	/* array of locked inodes */
	inode_t locks_array_move[MAX_LOCKS_ARRAY*2];

	char *parent_name, *new_parent_name, *child_name, *new_child_name;
	char name_copy[MAX_FILE_NAME], location_copy[MAX_FILE_NAME];
	
	int parent_inumber, new_parent_inumber, child_inumber, new_child_inumber;
	type pType, cType, new_pType;
	union Data pdata, cdata, new_pdata;
	/* sending errors to client */
	char message[OUTDIM];

	print_conditions();

	strcpy(name_copy, name);
	strcpy(location_copy, location);
	
	split_parent_child_from_path(name_copy, &parent_name, &child_name);
	split_parent_child_from_path(location_copy, &new_parent_name, &new_child_name);

	/* first argument verifications */
	parent_inumber = lookup(parent_name, locks_array_move);

	if (parent_inumber < 0) {
		sprintf(message, "failed to move %s, invalid parent dir %s\n", child_name, parent_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array*/
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		end_print_conditions();
		return FAIL;
	}

	inode_get(parent_inumber, &pType, &pdata);

	if(pType != T_DIRECTORY) {
		sprintf(message, "failed to move %s, parent %s is not a dir\n", child_name, parent_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		end_print_conditions();
		return FAIL;
	}

	child_inumber = lookup_sub_node(child_name, pdata.dirEntries);

	if (child_inumber == FAIL) {
		sprintf(message, "failed to move %s, does not exist in dir %s\n", name, parent_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		end_print_conditions();
		return FAIL;
	}

	inode_get(child_inumber, &cType, &cdata);

	/* second argument verifications */
	new_parent_inumber = lookup(new_parent_name, locks_array_move);

	if (new_parent_inumber < 0) {
		sprintf(message, "failed to move %s, dir %s doesn't exists\n", child_name, location_copy);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		end_print_conditions();
		return FAIL;
	}

	inode_get(new_parent_inumber, &new_pType, &new_pdata);

	if(new_pType != T_DIRECTORY) {
		sprintf(message, "failed to move %s, new parent %s is not a dir\n", child_name, location_copy);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		end_print_conditions();
		return FAIL;
	}

	new_child_inumber = lookup_sub_node(new_parent_name, pdata.dirEntries);

	if (new_child_inumber != FAIL) {
		sprintf(message, "failed to move %s, new child %s already exists\n", child_name, new_child_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		end_print_conditions();
		return FAIL;
	}

	if (strcmp(new_parent_name, name) == 0){
		sprintf(message, "failed to move %s, invalid argument\n", child_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		end_print_conditions();
		return FAIL;
	}

	if (strcmp(child_name, new_child_name) != 0){
		sprintf(message, "failed to move %s, invalid argument\n", child_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		end_print_conditions();
		return FAIL;
	}

	/* add entry */
	/* write lock new_parent_inumber */
	wr_lock(inode_table[new_parent_inumber].lock);
	if (dir_add_entry(new_parent_inumber, child_inumber, child_name) == FAIL){
		sprintf(message, "failed to add entry %s to dir %s\n", child_name, new_parent_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlock (write lock) new_parent_inumber */
		unlock(inode_table[new_parent_inumber].lock);
		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		end_print_conditions();
		return FAIL;
	}
	/* unlock (write lock) new_parent_inumber */
	unlock(inode_table[new_parent_inumber].lock);

	/* reset entry */
	/* write lock parent_inumber */
	wr_lock(inode_table[parent_inumber].lock);
	if (dir_reset_entry(parent_inumber, child_inumber) == FAIL){
		sprintf(message, "failed to reset entry %s in dir %s\n", child_name, parent_name);
		send_to_client(message, client_addr);
		printf("%s", message);

		/* unlock (write lock) parent_inumber */
		unlock(inode_table[parent_inumber].lock);
		/* unlocks all locks in array */
		for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
			unlock(locks_array_move[j].lock);
		}
		end_print_conditions();
		return FAIL;
	}
	/* unlock (write lock) parent_inumber */
	unlock(inode_table[parent_inumber].lock);

	/* unlocks all locks in array */
	for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
		unlock(locks_array_move[j].lock);
	}

	end_print_conditions();

	sprintf(message, "SUCCESS\n");
	send_to_client(message, client_addr);
	return SUCCESS;
}


/*
 * Print the fs tree into a file.
 * Input:
 *  - name: file name
 * Returns: SUCCESS or FAIL
 */
int print_to_file(char* name, struct sockaddr_un client_addr){
	FILE* fp;
	char message[OUTDIM];

    /* mutex lock */
    if (pthread_mutex_lock(&lock) != 0){
        fprintf(stderr, "Error locking mutex.\n");
        exit(EXIT_FAILURE);
    }

    stop_threads = 1;
 
    while (working_threads != 0){
    	if (pthread_cond_wait(&c, &lock) != 0){
            fprintf(stderr, "Error in cond wait.\n");
            exit(EXIT_FAILURE);
        }
    }

    fp = fopen(name, "w+");
	if (fp == NULL) {
        printf("Error creating output file.\n");
        exit(EXIT_FAILURE);
    }
    print_tecnicofs_tree(fp);
    stop_threads = 0;

    if (pthread_cond_broadcast(&t) != 0){
        fprintf(stderr, "Error in cond signal.\n");
        exit(EXIT_FAILURE);
    }
    /* mutex unlock */
    if (pthread_mutex_unlock(&lock) != 0){
        fprintf(stderr, "Error unlocking mutex.\n");
        exit(EXIT_FAILURE);
    }

    fclose(fp);

	sprintf(message, "SUCCESS\n");
	send_to_client(message, client_addr);
	return SUCCESS;
}


/*
 * Prints tecnicofs tree.
 * Input:
 *  - fp: pointer to output file
 */
void print_tecnicofs_tree(FILE *fp){
	inode_print_tree(fp, FS_ROOT, "");
}
