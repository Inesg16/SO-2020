/**************************
 * Grupo 2: 96729 e 96742 *
 **************************/

#ifndef FS_H
#define FS_H
#include "state.h"

#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>

#define MAX_LOCKS_ARRAY 20
#define INDIM 30
#define OUTDIM 512

void wr_lock(pthread_rwlock_t lock);
void rd_lock(pthread_rwlock_t lock);
void unlock(pthread_rwlock_t lock);
void send_to_client(char* message, struct sockaddr_un client_addr);

void init_fs();
void destroy_fs();
int is_dir_empty(DirEntry *dirEntries);
int create(char *name, type nodeType, struct sockaddr_un client_addr);
int delete(char *name, struct sockaddr_un client_addr);
int lookup(char *name, inode_t *locks_array);
int move (char *name, char *location, struct sockaddr_un client_addr);
int print_to_file(char* name, struct sockaddr_un client_addr);
void print_tecnicofs_tree(FILE *fp);

#endif /* FS_H */
