/*********************************
 * Projeto SO - Ano letivo 20/21 *
 * 3o Exercicio                  *
 *********************************
 * Grupo 2:                      *
 * Beatriz Urbano - 96729        *
 * Ines Gomes - 96742            *
 *********************************/


#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <ctype.h>
#include "fs/operations.h"
#include <pthread.h>
#include <sys/time.h>  /*  gettimeofday() */
#include <sys/types.h>
#include <math.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/uio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <strings.h>

#define MAX_COMMANDS 10
#define MAX_INPUT_SIZE 100


/* total number of threads (input) */
int numberThreads;

int sockfd;

pthread_cond_t t; /* stop_threads */
pthread_cond_t c; /* working_threads */
pthread_mutex_t lock;


void errorParse(){
    fprintf(stderr, "Error: command invalid\n");
    exit(EXIT_FAILURE);
}


void applyCommands(){
    socklen_t addrlen;
    struct sockaddr_un client_addr;
    char in_buffer[INDIM];
    int c;

    addrlen = sizeof(struct sockaddr_un);

    while (1){
        c = recvfrom(sockfd, in_buffer, sizeof(in_buffer)-1, 0, (struct sockaddr *)&client_addr, &addrlen);
        if (c <= 0) continue;
        //if client didn't end the message with '\0', add it 
        in_buffer[c]='\0';

        printf("Received message from: %s\n", client_addr.sun_path);
    
        char token;
        char name[MAX_INPUT_SIZE], type[MAX_INPUT_SIZE];
        int numTokens = sscanf(in_buffer, "%c %s %s", &token, name, type);

        if (numTokens < 2) {
            fprintf(stderr, "Error: invalid command in Queue\n");
            exit(EXIT_FAILURE);
        }

        int searchResult;
        /* array of inodes to be locked by lookup */
        inode_t locks_array[MAX_LOCKS_ARRAY];
        char message[OUTDIM];
      
        switch (token) {
            case 'c':
                if (strcmp(type, "f") == 0){
                    printf("Create file: %s\n", name);
                    create(name, T_FILE, client_addr);
                    break;
                }
                if (strcmp(type, "d") == 0){
                    printf("Create directory: %s\n", name);
                    create(name, T_DIRECTORY, client_addr);
                    break;
                }
                else{
                    fprintf(stderr, "Error: invalid node type\n");
                    exit(EXIT_FAILURE);
                }
                break;

            case 'l':
                searchResult = lookup(name, locks_array);

                /* unlocks all locks in array*/
                for (int j = 0; j < MAX_LOCKS_ARRAY; j++){
                    unlock(locks_array[j].lock);
                }

                if (searchResult >= 0){
                    sprintf(message, "SUCCESS\n");
                    send_to_client(message, client_addr);
                    printf("Search: %s found\n", name);
                }
                else{
                    sprintf(message, "Search: %s not found\n", name);
                    send_to_client(message, client_addr);
                    printf("%s", message);
                }
                break;

            case 'd':
                printf("Delete: %s\n", name);
                delete(name, client_addr);
                break;

            case 'm':
                printf("Move: %s to %s\n", name, type );
                move(name, type, client_addr);
                break;

            case 'p':
                printf("Printed tree to %s\n", name);
                print_to_file(name, client_addr);
                break;

            default: { /* error */
                fprintf(stderr, "Error: command to apply\n");
                exit(EXIT_FAILURE);
            }
        }
    }
}

/* given the number of threads it creates and joins them*/
void threads(void (*f)) {
    pthread_t tid[numberThreads];

    for (int i = 0; i < numberThreads; i++){
        if (pthread_create(&tid[i], NULL, f, NULL) != 0){
            fprintf(stderr, "Error creating thread.\n");
            exit(EXIT_FAILURE);
        }
    }

    for (int j = 0; j < numberThreads; j++){
        if (pthread_join(tid[j], NULL) != 0){
            fprintf(stderr, "Error joining thread.\n");
            exit(EXIT_FAILURE);
        }
    }
}

int setSockAddrUn(char *path, struct sockaddr_un *addr) {

    if (addr == NULL)
        return 0;

    bzero((char *)addr, sizeof(struct sockaddr_un));
    addr->sun_family = AF_UNIX;
    strcpy(addr->sun_path, path);

    return SUN_LEN(addr);
}


/* Arguments: numthreads socketname */
int main(int argc, char **argv) {
    struct sockaddr_un server_addr;
    socklen_t addrlen;

    char *path;

    /* argument verifications */
    if (argc != 3){
        errorParse();
    }

    numberThreads = atoi(argv[1]);
    if (numberThreads <= 0){
        errorParse();
    }

    if (strlen(argv[2]) <= 0){
        errorParse();
    }

    /* init filesystem */
    init_fs();

    /* initializing mutex and cond var */
    if (pthread_mutex_init(&lock, NULL) != 0){
        fprintf(stderr, "Error initializing mutex.\n");
        exit(EXIT_FAILURE);
    }

    if (pthread_cond_init(&t, NULL) != 0){
        fprintf(stderr, "Error initializing cond var.\n");
        exit(EXIT_FAILURE);
    }

    if (pthread_cond_init(&c, NULL) != 0){
        fprintf(stderr, "Error initializing cond var.\n");
        exit(EXIT_FAILURE);
    }

    /* initializing server socket */
    if ((sockfd = socket(AF_UNIX, SOCK_DGRAM, 0)) < 0) {
        perror("server: can't open socket");
        exit(EXIT_FAILURE);
    }

    path = argv[2];

    unlink(path);

    addrlen = setSockAddrUn (argv[2], &server_addr);
    if (bind(sockfd, (struct sockaddr *) &server_addr, addrlen) < 0) {
        perror("server: bind error");
        exit(EXIT_FAILURE);
    }

    threads(applyCommands);

    /* destroying mutex and cond var */
    if (pthread_mutex_destroy(&lock) != 0){
        fprintf(stderr, "Error destroying mutex.\n");
        exit(EXIT_FAILURE);
    }

    if (pthread_cond_destroy(&t) != 0){
        fprintf(stderr, "Error destroying cond var.\n");
        exit(EXIT_FAILURE);
    }

    if (pthread_cond_destroy(&c) != 0){
        fprintf(stderr, "Error destroying cond var.\n");
        exit(EXIT_FAILURE);
    }

    /* this part will never be reached */
    /* close and delete the socket */
    close(sockfd);
    unlink(argv[2]);
    /* release allocated memory */
    destroy_fs();
    exit(EXIT_SUCCESS);
}
